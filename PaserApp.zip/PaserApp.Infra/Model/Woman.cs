﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaserApp.Infra.Model
{

    
    public class Woman : Human
    {
        public DummyObject Dummy { get; set; }
    }
}
