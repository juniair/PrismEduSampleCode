﻿using System.Windows.Controls;

namespace XmlDisplay.Views
{
    /// <summary>
    /// Interaction logic for XmlView
    /// </summary>
    public partial class XmlView : UserControl
    {
        public XmlView()
        {
            InitializeComponent();
        }
    }
}
